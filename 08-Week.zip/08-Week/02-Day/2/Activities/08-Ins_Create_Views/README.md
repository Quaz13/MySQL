# Instructor Do: Create Views (10 min)

In this activity, students will learn how to create and utilize views—virtual tables that can be created from a single table, multiple tables, or another view. This activity makes use of `rental_db`.

**Files:**

* [query.sql](Solved/query.sql)

## Instructions

Use the `SQL Views` section of the slides to begin the discussion of views.

Tell students:

* Up to this point, we have seen relatively long queries, especially when they involve joins and subqueries.

* There is a way to save a long query under a name and run that name as a shortcut.

Slack out the following query and ask the students to run it:

  ````sql
  SELECT s.store_id, SUM(amount) AS Gross
  FROM payment AS p
    JOIN rental AS r
    ON (p.rental_id = r.rental_id)
      JOIN inventory AS i
      ON (i.inventory_id = r.inventory_id)
        JOIN store AS s
        ON (s.store_id = i.store_id)
        GROUP BY s.store_id;
  ````

* The query is used to monitor the total sales from each store, which is something a company executive would want to look up often.

* Notice that an alias is used to narrow table names down to a single letter. Instead of having to type this query, we can store it under a `view`:

  ```sql
  CREATE VIEW total_sales AS
  SELECT s.store_id, SUM(amount) AS Gross
  FROM payment AS p
  JOIN rental AS r
  ON (p.rental_id = r.rental_id)
    JOIN inventory AS i
    ON (i.inventory_id = r.inventory_id)
      JOIN store AS s
      ON (s.store_id = i.store_id)
      GROUP BY s.store_id;
  ```

Point out that the query is identical to the one above, except for the first line:

  ```sql
  CREATE VIEW total_sales AS
  ```

* A `view` is created under the name `total_sales`.

* Created views can be found on the left sidebar in MySQLWorkbench.

* The rest of the query follows `AS`.

Run the query. To execute this view, type the following:

  ```sql
  SELECT *
  FROM total_sales;
  ```

Simple! Ask a student to guess how we might delete a view.

  ```sql
  DROP VIEW total_sales;
  ```

For the remainder of the activity, have students create and drop their views.

---

© 2019 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
