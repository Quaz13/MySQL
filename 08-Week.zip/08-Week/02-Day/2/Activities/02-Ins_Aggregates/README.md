# Instructor Do: Aggregate Functions, Aliases, and Grouping (10 min)

In this activity, students will learn how to use aggregate functions, aliases, and groupby operations to analyze data on a higher-level or aggregated perspective. This demonstration will utilize the `rental_db` database we created in the beginning of the class. 

**Files:**

* [schema.sql](Solved/schema.sql)


## Instructions

Use the `Aggregate Functions` section of the slides and review the following:

* Aggregate functions allow calculations on a set of values and return a singular value.

* Some of the most commonly used aggregates are `AVG`, `COUNT`, `MIN`, `MAX`, and `SUM`.

* Aggregates are often combined with `GROUP BY`, `HAVING`, and `SELECT`.

Then, select the `rental_db` database in MySQLWorkbench and open a query window.

Run `SELECT * FROM film;` and count the number of rows.

Run `SELECT COUNT(film_id) FROM film;` and explain the following:

* Using `COUNT()` is an easier way to count the rows.

* The `COUNT()` function is an aggregate.

Now that the number of `film_id` entries has been counted, it's easy to see a total of 1,000 films.

Point out that the name of the field returned is `COUNT(film_id)`, which doesn't describe the column accurately. MySQL has a way to change the column names and make them more descriptive.

Run the following:

  ```sql
  SELECT COUNT(film_id) AS "Total films"
  FROM film;
  ```

Explain the following:

* `AS 'Total films'` is a technique called **aliasing**.

* Aliasing creates an `alias`, or a new name for the column.

* Using an alias does not change the table or the database in any way. Aliasing is only a measure of convenience, used to view a column or to create shortcuts for columns or other data.

* The `COUNT()` function is great to see the number of movies, but it isn't informative enough when searching for the number of specific ratings, like G or PG-13. This is where `GROUP BY` comes into play.

Run the following code:

  ```sql
  SELECT rating, COUNT(film_id) AS "Total films"
  FROM film
  GROUP BY rating;
  ```

Explain the following:

* The `GROUP BY` method will first group by the column indicated.

* Aggregates are used to get the values for any columns not included in the `GROUP BY` clause.

* Here, the `COUNT()` function will count the `film_id` for each `rating`.


Explain that we can aggregate data in other ways besides counting. For example, `sum`, `avg`, `min`, and `max` are all valid aggregate functions to apply to the data.

Ask the class how to query the average rental period for *all* movies. To demonstrate, run the following query:

  ```sql
  SELECT AVG(rental_duration)
  FROM film;
  ```

To demonstrate how to add an alias to the `AVG()` function, run the following:

  ```sql
  SELECT AVG(rental_duration) AS "Average rental period"
  FROM film;
  ```

Put it all together by running the following query, showing how to `GROUP BY` rental duration, get the average `rental_rate`, and give it an alias.

  ```sql
  SELECT  rental_duration, AVG(rental_rate) AS "Average rental rate"
  FROM film
  GROUP BY rental_duration;
  ```

Ask a student to explain the query.

* Movies that can be rented for three days cost an average of $2.82 to rent, movies that can be rented for four days cost an average of $2.97 to rent, and so on.

* SQL can also return the rows that contain the minimum and maximum values in a column using `MIN()` and `MAX()` respectively.

  ```sql
  -- Find the rows with the minimum rental rate
  SELECT  rental_duration, MIN(rental_rate) AS "Min rental rate"
  FROM film
  GROUP BY rental_duration;

  -- Find the rows with the maximum rental rate
  SELECT  rental_duration, MAX(rental_rate) AS "Max rental rate"
  FROM film
  GROUP BY rental_duration;
  ```

Mention that these aggregate functions calculate and retrieve data, but they do not alter the data. That is, they do not modify the database.

Explain that there are many other aggregate functions students can research. Slack out [SQL functions](https://www.tutorialspoint.com/sql/sql-useful-functions.htm) to the class for future reference.

Answer any questions before moving on.

---

© 2019 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
