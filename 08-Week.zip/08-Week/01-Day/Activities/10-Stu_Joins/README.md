# Joining the Big Banks

In this activity, you will be using joins to query payment information and associated bank information via a common bank routing number.

**Files:**

* [schema.sql](Solved/schema.sql)
* [seed.sql](Solved/seed.sql)

## Instructions

1. Create a new database named `payments_db`.

2. Copy, paste and run the contents of `schema.sql` to create the `payments`, `banks`, and `customer` tables.
    
    **Note:** Remember to refresh the database; newly created tables will not immediately appear.

3. Copy, paste and run the contents of `seed.sql` to populate the tables. 

4. Perform the correct join for each of the following use cases using the common `bank_routing_number` from the `payments` and `banks` tables:

    **Note:** Assume the `payments` table is the designated "left" table and the `banks` table is the designated "right" table.

    * `INNER JOIN` - Return all payment records with matching bank routing numbers in the banks table.


    * `LEFT JOIN` - Return all payment records regardless if there is a matching bank routing number in the banks table.

 

    * `RIGHT-JOIN` - Return all bank records regardless if there is a matching bank routing number in the payments table.


    * `UNION OF LEFT & RIGHT JOINS`- Return all records from both tables regardless if there is a matching bank routing number in either table.


    * `CROSS JOIN`- Return paired records from both tables where each row of the first table is paired with each row of the second table.

5. **Bonus**: Join the customer table with the payments and banks tables to find the customers who have Wells Fargo bank accounts. Return the following columns:

    * `payment_id`
    * `bank_number`
    * `bank_routing_number`
    * `bank_name`
    * `first_name`
    * `last_name`


---

© 2019 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
