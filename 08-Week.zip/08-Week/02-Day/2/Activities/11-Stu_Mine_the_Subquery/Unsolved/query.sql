-- Using subqueries, display the titles of all films of which
-- employee `Jon Stephens` rented out to customers.


-- Using subqueries, find the total rental amount paid for the film `ACE GOLDFINGER`
