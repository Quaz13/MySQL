-- Create a new table
CREATE TABLE states (
  state_name VARCHAR(50),
  state_abbreviation CHAR(2),
  population INT,
  state_property_tax_rate FLOAT
);
