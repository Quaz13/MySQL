-- Find the count of payments per customer in descending order


-- Find the top 5 customers who have spend the most money


-- Find the bottom 5 customers who have spend the least money


-- Find the top 10 customers with the highest average payment
-- rounded to two decimal places


-- BONUS 1



-- BONUS 2



