-- 1. Find the customer first and last names of those who have made payments.


-- 2. Find the staff email addresses of those who have helped customers make payments.


-- 3. Find the rental records of all films that have been rented out and paid for.


-- BONUS

