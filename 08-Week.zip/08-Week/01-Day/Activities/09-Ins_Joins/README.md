# Instructor Do: Joins (15 min)

In this activity, you will be using joins to query `mortgage_db`.

**Files:** 

* [schema.sql](https://github.com/coding-boot-camp/nflx-java/blob/master/01-Lesson-Plans/08-Week/01-Day/1/Activities/10-Stu_Joins/Solved/schema.sql)
* [seed.sql](https://github.com/coding-boot-camp/nflx-java/blob/master/01-Lesson-Plans/08-Week/01-Day/1/Activities/09-Ins_Joins/Solved/seed.sql)
* [query.sql](https://github.com/coding-boot-camp/nflx-java/blob/master/01-Lesson-Plans/08-Week/01-Day/1/Activities/09-Ins_Joins/Solved/query.sql)

## Instructions

1. Create a new database named `mortgage_db`.

2. Copy the code from [schema.sql](Solved/schema.sql) to create the tables, and then import the corresponding data by copying and pasting the contents of [seed.sql](Solved/seed.sql).

3. Remember to refresh the database; newly created tables will not immediately appear.Right-click the tables and choose the first option `Select Rows-Limit 100` to confirm that the data exists.

4. Point out that both tables have matching values within the `mortgage_id` column of the `sales` table and the `mortgage_id` of the `mortgage` table. Because there are common values, it is possible to join these tables together.

5.  From the [query.sql](Solved/query.sql) file, copy and paste the code performing an `inner join` on the two tables:

  ```sql
  SELECT
    sales.sales_id,
    sales.payment_id,
    sales.mortgage_id,
    sales.loan_amount,
    sales.loan_date,
    mortgage.mortgage_id,
    mortgage.mortgage_name,
    mortgage.mortgage_rate
  FROM sales
  INNER JOIN mortgage ON sales.mortgage_id = mortgage.mortgage_id;
  ```

**Note:** Some students may have advanced knowledge of SQL queries and use aliases in their solutions. Using aliases is not necessary for today's activities, we just want to give students a few examples of this. 

  ```sql
  -- Advanced INNER JOIN solution
  SELECT
    a.sales_id,
    a.payment_id,
    a.mortgage_id,
    a.loan_amount,
    a.loan_date,
    b.mortgage_id,
    b.mortgage_name,
    b.mortgage_rate
  FROM sales as a
  INNER JOIN mortgage as b ON a.mortgage_id = b.mortgage_id;
```

Point out the following about SQL joins:

* In SQL joins, the columns that should be viewed after the join must be declared in the initial `SELECT` statement.

* There are five primary types of joins that can be used with MySQL:

  * `INNER JOIN` returns records that have matching values in both tables.
       
       ```sql
      -- Perform an INNER JOIN and return all columns
      SELECT *
      FROM sales
      INNER JOIN mortgage ON sales.mortgage_id = mortgage.mortgage_id  
        ```
     
  * `LEFT JOIN` returns all records from the left table and the matched records from the right table. Unmatched left-side records will contain NULL values for right-side columns.
  
     ```sql
      -- Perform a LEFT JOIN and return all columns
      SELECT *
      FROM sales
      LEFT JOIN mortgage ON sales.mortgage_id = mortgage.mortgage_id;
        ```
    
   * `RIGHT JOIN` returns all records from the right table and the matched records from the left table. Unmatched right-side records will contain NULL values for left-side columns.
  
      ```sql
      -- Perform a RIGHT JOIN and return all columns
      SELECT *
      FROM sales
      RIGHT JOIN mortgage ON sales.mortgage_id = mortgage.mortgage_id;
        ```
    
    * `FULL OUTER JOIN` returns all records from the left and right tables, displaying both matched records and unmatched records with NULL values. Explain to students that MySQL does not support `full outer joins`. However, there is a way to emulate a `full outer join` on a RDBMS that doesn't support it.  
    
    * `CROSS JOIN` returns records that match every row of the left table with every row of the right table. This type of join has the potential to make very large tables.
  
      ```sql
      -- Perform a CROSS JOIN and return all columns
      SELECT *
      FROM sales
      CROSS JOIN mortgage;
        ```
Demonstrate a couple of different joins that can be performed. Then answer any questions before moving on to the next activity. 

---

© 2019 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
