--1. What is the average payment amount?


--2. What is the total payment amount?


--3. What is the minimum payment amount?


--4. What is the maximum payment amount?


--5. What is the count of payments for each customer?


--6. How many customers has each staff serviced?

