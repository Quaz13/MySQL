-- View table columns and datatypes
SELECT * FROM mortgage;