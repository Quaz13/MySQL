# Instructor Do: Import Data (15 min)

In this activity, instructors will help students prepare for today's lesson by importing the necessary data to their databases. 

**Files:**

* [schema.sql](Solved/schema.sql)

* [seed.sql](Solved/seed.sql)

* [query.sql](Solved/query.sql)

Explain to the class that today's activities will require a few tables to be imported into a database.

For this class, students will create and populate tables from data provided by the [sakila database](https://dev.mysql.com/doc/sakila/en/), which is a sample database used to learn MySQL. Data files are provided within the [solved](https://github.com/coding-boot-camp/nflx-java/tree/master/01-Lesson-Plans/08-Week/01-Day/2/Activities/01-Evr_Import_Data/Solved) folder. An example for importing the data is provided below.

Together with the class, walk through the following steps:

* From MySQLWorkbench, run the contents of `schema.sql`. This will create a database, named `rental_db`, along with the necessary tables.

* Now we will now populate the tables using the contents of `seed.sql`. Copy, paste and run the contents of `seed.sql`. This will fill the tables with data that can be used to run our queries. 

* Run `SELECT * FROM actor LIMIT 100;` to confirm that the import was successful.

**Optional:** Right-click the "actor" table and choose the first option "Select Rows - Limit 100".

Then, slack out `schema.sql` and `seed.sql` files to the class. Mention that while we could import each seed & schema file one by one, it will be quicker to create and import all of our data at once. Have students copy and paste the contents of the files in their query editors and execute the code.

**Note:** Use the CTRL+C and CTRL+A hotkeys to quickly copy and paste all the contents of the files.

The TAs should walk around the classroom to assist students with the database upload.



---

© 2019 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
