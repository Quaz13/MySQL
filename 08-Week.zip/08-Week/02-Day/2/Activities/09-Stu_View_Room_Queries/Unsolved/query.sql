-- Create customer revenue view


-- Query customer revenue view


-- BONUS
-- Create staff sales view


-- Query staff sales view
