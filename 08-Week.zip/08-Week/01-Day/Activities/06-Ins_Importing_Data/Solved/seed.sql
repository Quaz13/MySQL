INSERT INTO mortgage
(mortgage_name, mortgage_rate)
VALUES
('10-Year Fixed Loan',0.03),
('15-Year Fixed Loan',0.035),
('20-Year Fixed Loan',0.04),
('30-Year Fixed Loan',0.045),
('40-Year Fixed Loan',0.05);