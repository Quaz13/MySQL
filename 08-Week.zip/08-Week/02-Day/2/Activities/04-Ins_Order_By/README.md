# Instructor Do: Order By Aggregates (10 min)

In this activity, students will learn how to sort (ascending or descending) their datasets by a specific column. This activity utilizes the `rental_db` we created earlier. 

**File:** 
 [query.sql](Solved/query.sql)

## Instructions

Explain that aggregate functions return the results in a random order. This can be tough when trying to find the top or bottom numerical results.

Open MySQLWorkbench and demonstrate the following:

* MySQL has a function called `ORDER BY` that will solve this issue. `ORDER BY` is added toward the end of a query, and by default will sort the results by ascending values.

  ```sql
  SELECT film_id, AVG(length)  AS "avg length" FROM film
  GROUP BY film_id
  ORDER BY "avg length";
  ```

* MySQL will add a lot of numbers after the decimal; in this case, the numbers added are zeros. To reduce the numbers after the decimal, use `ROUND()`. This takes the parameters `ROUND(<value>, <number of decimal places>)`, which rounds the value down to the specified number of decimal places.

  ```sql
  SELECT film_id, ROUND(AVG(length), 2)  AS "avg length" FROM film
  GROUP BY film_id
  ORDER BY "avg length";
  ```

* The `ORDER BY` statement can organize by descending values by adding `DESC`.

  ```sql
  SELECT film_id, ROUND(AVG(length), 2)  AS "avg length" FROM film
  GROUP BY film_id
  ORDER BY "avg length" DESC;
  ```

* Top results can also be taken by limiting the amount returned using `LIMIT`.

  ```sql
  SELECT film_id, ROUND(AVG(length), 2)  AS "avg length" FROM film
  GROUP BY film_id
  ORDER BY "avg length" DESC
  LIMIT 5;
  ```

Answer any questions before moving on.



---

© 2019 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
